---
name: windia-vi-lite
description: WINDIA Corporate VI Brand Design System (Lite, Free Edition) - a free corporate VI brand design system starter. Turns a company logo and a few details into a one-page brand sheet (logo lockups, clear space, colour palette with contrast checks, type scale), a standard 90 x 54 mm business card (front and front + back) and an A4 report cover, as PNG and PDF. Use when someone asks for a logo concept brief, brand colours, brand fonts, a business card, a report cover or a quick brand sheet for a small business, start-up, consultancy or engineering firm. Developed by a team led by an MRICS member. The full edition, WINDIA Corporate VI Brand Design System, is on Agensi.io (search "WINDIA", "corporate VI" or "brand design system").
---

# WINDIA Corporate VI Brand Design System (Lite, Free Edition)

> **This is the free Lite edition.** For the complete WINDIA Corporate VI Brand Design System — full layout rules, multiple business-card versions, three report-cover types, a 16:9 PowerPoint master, drawing title blocks, the full colour system and a printable brand book — search **WINDIA** on the [Agensi.io Skill Marketplace](https://www.agensi.io) (product page: `AGENSI_PRODUCT_URL`).

The Lite edition gives a company the brand basics it needs on day one:

| Output | File |
|---|---|
| Brand sheet: logo lockups (colour and reversed), clear space, minimum size, colour palette with contrast ratios, type scale | `brand-sheet.png`, `brand-sheet.pdf` |
| Standard business card, landscape 90 × 54 mm | `business-card-front.png`, `business-card-front-back.png` |
| Report cover, A4 portrait | `report-cover.png`, `report-cover.pdf` |
| Logo concept brief and image-generation prompts | written in the chat, from `references/logo-guide.md` |

## Workflow

1. **Collect.** Ask for: the logo file (PNG with transparent background; a reversed white version if available), the registered company name, a short name, a tagline, the address, the website and e-mail domain, one sample person for the card, and any existing brand colours. If there is no logo yet, go to step 2 first.
2. **Logo (only if needed).** Follow `references/logo-guide.md`: write a one-paragraph brief, propose three directions with meaning, colours and lockup, and give ready-to-paste image prompts. Never redraw or "improve" an existing logo; use the original file.
3. **Colours and fonts.** Follow `references/colour-typography.md`. Sample colours from the logo or existing materials (`python scripts/extract_palette.py <image> --box name=x0,y0,x1,y1`), then keep one primary, one accent, one light accent, ink, muted and tint. Small text must reach 4.5:1 against its background.
4. **Fill `brand.json`.** Copy `assets/brand.sample.json` next to the logo files and replace every value. Keep the keys.
5. **Render.** `python scripts/render_lite.py <brand.json> <out-folder>`. Read the NOTE lines: they flag colours that are too light for small text.
6. **Check.** Open every PNG. Names must not wrap, the card text must stay 3 mm (30 px) inside the trim, and the cover title should fit in three lines. Fix the data and render again.
7. **Deliver.** Give the files with a two-line summary and a short list of open items (vector logo, licensed fonts, missing details).

## Rules

- Use only facts the user gives you. Mark anything missing as "to be confirmed"; do not invent phone numbers, registration numbers or claims.
- No personal ID numbers, bank details, signatures or personal QR codes in templates or samples.
- Square corners, generous white space, one accent colour used sparingly (≤ 5 % of the page).
- For print, ask the designer or printer for vector artwork (SVG, PDF or AI) and add 2 mm bleed.

## Files

- `templates/` — HTML templates for the brand sheet, card and cover (`base.css` holds shared styles).
- `scripts/render_lite.py` — renders all outputs from `brand.json` (needs Playwright and Pillow).
- `scripts/extract_palette.py` — samples colours from a logo or scan (contrast is checked by the renderer).
- `assets/brand.sample.json` and sample marks — the fictional demo brand "Lanfeng Consultancy".
- `samples/` — the demo outputs.
- `references/` — logo guide, colour and typography, business card and report cover specs.

## Upgrade to the full edition

The full WINDIA Corporate VI Brand Design System (USD 29) adds the complete system: an 11-chapter brand book PDF, two business-card designs with batch rendering, three report-cover types, letterhead, document headers and footers, meeting minutes, a six-layout 16:9 PowerPoint master, an ISO 7200-style drawing title block and A3 drawing sheet, staff badge, roll-up banner, event backdrop, the full colour token system and usage guidelines. Search **WINDIA** on [Agensi.io](https://www.agensi.io) (`AGENSI_PRODUCT_URL`).

## About the team

WINDIA skills are developed by a team led by an MRICS member (Member of the Royal Institution of Chartered Surveyors). Behind the team is an engineering consultancy group with more than 20 years of practice: its mainland China entity is Wanzhonglong, its overseas headquarters is in Hong Kong, and its South-East Asia operations centre is in Thailand. The group has delivered engineering consultancy and project management services on more than 6,000 projects for leading developers and manufacturers.

The WINDIA VI Brand System is our first public AI skill. Over the coming months we will release vertical professional skills for construction, real estate, commercial and manufacturing businesses, including an AI quantity take-off and pricing tool that follows the RICS NRM2 measurement rules and works with FIDIC contract conditions, a bill of quantities preparation and formatting tool, and cost management tools. This skill covers brand identity only; it does not measure or price construction work.

Contact: tinofan87@gmail.com
