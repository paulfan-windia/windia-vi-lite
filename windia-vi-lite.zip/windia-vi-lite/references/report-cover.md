# Report cover (Lite Edition)

- Size: A4 portrait (210 × 297 mm; 794 × 1123 px), PDF and PNG.
- Header: horizontal lockup, then a 2 px rule fading from the primary colour to the light accent.
- Title block about one third down the page: report type in capitals (accent), title (heading font, up to three lines), subtitle in capitals (muted), a short accent rule.
- Information rows: Client, Report No., Prepared by, Date.
- Footer: primary-colour band with an accent top edge, company name (light accent), address, website.
- Keep sample data clearly marked as "(sample)". No client names or figures from real projects in templates.
- The full edition adds two more cover types (full navy and split panel) and the matching document headers and footers.
