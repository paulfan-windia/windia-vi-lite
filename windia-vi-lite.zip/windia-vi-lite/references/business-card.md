# Standard business card (Lite Edition)

- Size: landscape 90 × 54 mm, 2 mm bleed for print; rendered at 20 px/mm (1800 × 1080 PNG).
- Safe area: all text at least 3 mm (30 px at 10 px/mm) inside the trim.
- Front: name (heading font, accent colour), title in capitals, a short accent rule with a dot, four contact rows (M mobile, T phone, E e-mail, A address), logo top right, primary-colour band at the bottom with the company name and website.
- Back: primary colour, reversed logo, short name, tagline, a short accent rule, address and website.
- E-mail format: one rule for the whole company (for example firstnamelastname@domain).
- Print the main job title only.
- Every person gets two files: `business-card-front.png` and `business-card-front-back.png` (front above back, for sharing in chat).
- No personal QR codes or real phone numbers in templates or samples; use placeholders such as +44 7XXX XXXXXX.
