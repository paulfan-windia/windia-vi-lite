# Colour and typography (Lite Edition)

## Palette
| Role | Key in brand.json | Rule |
|---|---|---|
| Primary | `primary` | Dark, trustworthy colour for bands, headings and table headers. Must reach 4.5:1 with white text. |
| Accent | `accent` | Rules, names, highlights. Usually below 4.5:1 on white: large type (24 px +) and lines only. |
| Accent light | `accent_light` | Accent on dark backgrounds (text on the primary colour). |
| Ink | `ink` | Body text. |
| Muted | `muted` | Secondary text and labels (must stay ≥ 4.5:1 on white). |
| Tint | `tint` | Alternate table rows and panels. |

- Proportion: white 70 % · primary 20–25 % · accent ≤ 5 %.
- Sample colours from the original logo or printed materials; sample the same colour in two or three places and take the average.
- Contrast: 4.5:1 for normal text, 3:1 for large text (24 px + or 18.5 px bold +) and graphic lines. The renderer prints a NOTE for any accent that fails 4.5:1.
- For print, confirm CMYK or spot colours with a printed proof.

## Typography
| Style | Use | Default |
|---|---|---|
| Heading (serif) | Titles, names, company name | Noto Serif / Georgia, 700 |
| Body (sans) | Text, tables, contact rows | Noto Sans / Arial, 400 |
| Label | Capitalised labels, 11–13 px, wide tracking (.16–.24 em) | Body font, 500 |

Sizes: display 34–44 px; heading 22–28 px; body 14–15 px (10.5–12 pt in Word); labels 10–12 px. Line height 1.6–1.75.
Fonts are free to use (SIL Open Font License). If the company has licensed brand fonts, change `fonts.heading` and `fonts.body` in brand.json.
