# Logo guide (Lite Edition)

## If the company already has a logo
Use the original file. Never redraw, trace, recolour or "tidy up" a logo. Ask for:
- the highest-resolution colour version (PNG with transparent background, or SVG / PDF / AI);
- a single-colour or reversed (white) version if one exists.
If only a photo or a low-resolution file exists, crop the original pixels and note "vector artwork to be supplied" in the open items.

## If the company needs a logo concept
1. **Brief (one paragraph):** company name, sector, audience, three personality words (for example: steady, precise, international), colours to use or avoid, where the logo will live (cards, reports, site boards, web).
2. **Three directions.** For each one give:
   - concept and meaning (one or two sentences);
   - mark description (shapes, proportions, negative space);
   - colours (hex), with the primary and the accent;
   - lockups: horizontal (mark left, name right) and stacked (mark above);
   - a ready-to-paste image prompt (below).
3. **Choose one, then refine** in a vector tool before any print use. Image generators give concepts, not production artwork.

### Prompt template
```
Minimal corporate logo for "<COMPANY NAME>", a <SECTOR> company. <MARK DESCRIPTION>.
Flat vector style, geometric, square corners, no gradients, no 3D, no text effects.
Colours: <PRIMARY HEX> and <ACCENT HEX> on a plain white background.
Centered, generous white space, high resolution, suitable for a business card and a report cover.
```
Variants: add "single colour navy version" or "white version on <PRIMARY HEX> background" for mono and reversed artwork.

## Lockup rules
- Clear space: at least 1X on every side, where X is the height of the accent element in the mark (or one third of the mark height if there is no accent).
- Minimum size: mark 8 mm (24 px) high; horizontal lockup 18 mm (40 px) wide.
- Don'ts: stretch, squash, rotate, recolour, outline, add shadows or gradients, place on busy photos or low-contrast backgrounds, use retired versions.
- Colour lockup on white or very light backgrounds; reversed (white) lockup on the primary colour.
