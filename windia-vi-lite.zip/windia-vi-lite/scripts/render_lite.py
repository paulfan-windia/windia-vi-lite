#!/usr/bin/env python3
"""WINDIA Corporate VI Brand Design System (Lite) renderer: brand.json -> brand sheet, standard business card and report cover.

Usage:
  python scripts/render_lite.py <brand.json> <out-folder>

Outputs (English file names):
  brand-sheet.png / brand-sheet.pdf          one-page logo, colour and type sheet (A4 landscape)
  business-card-front.png                    90 x 54 mm front, 1800 x 1080 px
  business-card-front-back.png               front above back, for sharing in chat
  report-cover.png / report-cover.pdf        A4 portrait

Logo files named in brand.json ("logo", "logo_reversed") are read from the same folder as brand.json.
Needs: pip install playwright pillow && python -m playwright install chromium
"""
import base64, json, pathlib, re, sys

HERE = pathlib.Path(__file__).resolve().parent
TPL = HERE.parent / 'templates'


def lum(hexc):
    hexc = hexc.lstrip('#')
    r, g, b = (int(hexc[i:i + 2], 16) / 255 for i in (0, 2, 4))
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def contrast(a, b):
    la, lb = sorted([lum(a), lum(b)], reverse=True)
    return (la + 0.05) / (lb + 0.05)


def data_uri(p):
    p = pathlib.Path(p)
    if not p.exists():
        return ''
    return 'data:image/png;base64,' + base64.b64encode(p.read_bytes()).decode()


def fill(html, data):
    def get(key):
        cur = data
        for part in key.split('.'):
            cur = cur.get(part, '') if isinstance(cur, dict) else ''
        return str(cur)
    return re.sub(r'\{\{([a-z_.]+)\}\}', lambda m: get(m.group(1)), html)


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    bj = pathlib.Path(sys.argv[1]).resolve(); out = pathlib.Path(sys.argv[2]).resolve(); out.mkdir(parents=True, exist_ok=True)
    B = json.loads(bj.read_text(encoding='utf-8'))
    C = B['colors']; Fn = B.get('fonts', {})
    css_vars = ':root{--primary:%s;--accent:%s;--accent-light:%s;--ink:%s;--muted:%s;--surface:%s;--tint:%s;--font-heading:%s;--font-body:%s}' % (
        C['primary'], C['accent'], C.get('accent_light', C['accent']), C['ink'], C['muted'], C.get('surface', '#ffffff'), C.get('tint', '#f4f4f4'),
        Fn.get('heading', 'Georgia, serif'), Fn.get('body', 'Arial, sans-serif'))
    data = dict(B)
    data['base_css'] = css_vars + (TPL / 'base.css').read_text(encoding='utf-8')
    data['logo_uri'] = data_uri(bj.parent / B.get('logo', ''))
    data['logo_rev_uri'] = data_uri(bj.parent / B.get('logo_reversed', '')) or data['logo_uri']
    names = {'primary': 'Primary', 'accent': 'Accent', 'accent_light': 'Accent light', 'ink': 'Ink', 'muted': 'Muted', 'tint': 'Tint', 'surface': 'Surface'}
    sw, warn = [], []
    for k in ('primary', 'accent', 'accent_light', 'ink', 'muted', 'tint'):
        if k not in C:
            continue
        r = contrast(C[k], '#ffffff')
        use = 'text & large type' if r >= 4.5 else ('large type & lines only' if r >= 3 else 'backgrounds only')
        if k in ('accent', 'accent_light') and r < 4.5:
            warn.append(f'{names[k]} {C[k]} is {r:.1f}:1 on white: use it for large type and lines, not small text.')
        sw.append(f'<div><i style="background:{C[k]}"></i><b>{names[k]}</b>{C[k].upper()}<br>{r:.1f}:1 on white · {use}</div>')
    data['swatches'] = ''.join(sw)
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        br = p.chromium.launch()
        def page(name, vw, vh, scale):
            html = fill((TPL / name).read_text(encoding='utf-8'), data)
            tmp = out / ('_' + name); tmp.write_text(html, encoding='utf-8')
            pg = br.new_page(viewport={'width': vw, 'height': vh}, device_scale_factor=scale)
            pg.goto(tmp.as_uri()); pg.wait_for_timeout(500)
            return pg, tmp
        pg, t = page('brand-sheet.html', 1123, 794, 2)
        pg.locator('#sheet').screenshot(path=str(out / 'brand-sheet.png'))
        pg.pdf(path=str(out / 'brand-sheet.pdf'), width='297mm', height='210mm', print_background=True); pg.close(); t.unlink()
        pg, t = page('business-card.html', 900, 1120, 2)
        pg.locator('#front').screenshot(path=str(out / 'business-card-front.png'))
        pg.locator('#back').screenshot(path=str(out / '_back.png')); pg.close(); t.unlink()
        pg, t = page('report-cover.html', 794, 1123, 2)
        pg.locator('#cover').screenshot(path=str(out / 'report-cover.png'))
        pg.pdf(path=str(out / 'report-cover.pdf'), width='210mm', height='297mm', print_background=True); pg.close(); t.unlink()
        br.close()
    from PIL import Image
    f = Image.open(out / 'business-card-front.png').convert('RGB'); b = Image.open(out / '_back.png').convert('RGB')
    sheet = Image.new('RGB', (f.width, f.height * 2 + 40), (236, 236, 236)); sheet.paste(f, (0, 0)); sheet.paste(b, (0, f.height + 40))
    sheet.save(out / 'business-card-front-back.png'); (out / '_back.png').unlink()
    for w in warn:
        print('NOTE:', w)
    print('done ->', out)


if __name__ == '__main__':
    main()
