#!/usr/bin/env python3
"""Sample brand colours from a scanned card / logo / brochure image.

Two modes:
  1) Whole image:   python extract_palette.py card.jpg
     -> the most frequent non-white colours (median-cut), with pixel counts.
  2) Named regions: python extract_palette.py card.jpg --box logo=860,70,1000,225 --box band=0,618,1079,650
     -> for each box: the 'core ink' (average of the darkest 8% non-white pixels, i.e. the true ink
        without anti-aliasing) and the q25 colour, plus a median-cut cluster list.

Why core ink: on a JPEG scan, text and thin rules are diluted by anti-aliasing and paper white,
so a plain average is too light. The darkest slice of the non-white pixels is the closest to the
printed colour. Gradients (gold type) need two boxes: one at the light end, one at the dark end.
Record which box each token came from in its usage note.
"""
import argparse
from PIL import Image

def hexc(c): return '#%02x%02x%02x' % tuple(c[:3])

def clusters(img, k=6):
    q = img.quantize(colors=k, method=Image.Quantize.MEDIANCUT)
    pal = q.getpalette()[: k * 3]
    out = []
    for count, idx in sorted(q.getcolors(), reverse=True):
        c = pal[idx * 3: idx * 3 + 3]
        if sum(c) < 720:  # skip paper white
            out.append((hexc(c), count))
    return out

def core(img, frac=0.08):
    data = img.get_flattened_data() if hasattr(img, 'get_flattened_data') else img.getdata()
    px = [tuple(p) for p in data if sum(p) < 720]
    if not px: return None, None, 0
    px.sort(key=sum)
    n = max(1, int(len(px) * frac)); s = px[:n]
    avg = tuple(sum(c[i] for c in s) // n for i in range(3))
    return hexc(avg), hexc(px[len(px) // 4]), len(px)

ap = argparse.ArgumentParser()
ap.add_argument('image')
ap.add_argument('--box', action='append', default=[], help='name=x0,y0,x1,y1 in pixels')
ap.add_argument('--k', type=int, default=8)
a = ap.parse_args()
im = Image.open(a.image).convert('RGB')
print(f'{a.image}: {im.size[0]}x{im.size[1]}')
if not a.box:
    for h, c in clusters(im, a.k): print(f'  {h}  {c} px')
for b in a.box:
    name, coords = b.split('=')
    box = tuple(int(v) for v in coords.split(','))
    r = im.crop(box)
    ink, q25, n = core(r)
    print(f'[{name}] core {ink}  q25 {q25}  ({n} non-white px)  clusters: ' +
          ', '.join(f'{h}:{c}' for h, c in clusters(r, 6)))
